//

module.exports = {
    //DB:'mongodb+srv://daniel:mern1234@cluster0-nx2vb.gcp.mongodb.net/test?retryWrites=true&w=majority'//conexion a la una base de datos
    DB: 'mongodb://localhost:27017/agencia'
}
